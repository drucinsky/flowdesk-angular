import { CaseCategory } from './case-category.enum';
import { CasePriority } from './case-priority.enum';
import { CaseStatus } from './case-status.enum';

export interface ICase {
  readonly id: string;
  readonly customer: string;
  readonly title: string;
  readonly category: CaseCategory;
  readonly priority: CasePriority;
  readonly status: CaseStatus;
  readonly sla: string;
  readonly assignee: string;
  readonly updatedAt: string;
}
